<?php
//Database Config
define('DB_SERVER', 'mariadb');
define('DB_USERNAME', 'admin');
define('DB_PASSWORD', 'password');
define('DB_NAME', 'dreamscape');