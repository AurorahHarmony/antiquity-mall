 </div> <!-- end .col -->
 </div> <!-- end .row -->
 </div> <!-- end .py-5 -->
 </div> <!-- end .container -->

 <?php require_once(__DIR__ . '/../../templates/footer.php') ?>