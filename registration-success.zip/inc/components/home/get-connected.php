    <div class="row justify-content-center">
      <div class="get-connected col-11 col-md-10 col-xl-8 col-xxl-7 text-white p-4">
        <div class="row">
          <div class="col-md-7 mb-3 mb-md-0 d-flex">
            <div class="get-connected-text">GET CONNECTED</div>
          </div>
          <div class="col-md-5">
            <div class="play-now-btn-hover">
              <a href="/account/downloads" class="play-now-btn">
                <div class="play-now-btn-text">PLAY NOW</div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>