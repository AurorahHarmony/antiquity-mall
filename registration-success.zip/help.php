<?php
$title = 'Help';

require_once('inc/templates/header.php')
?>

<div class="container py-5">
  <div class="py-5">
    <h1>Help</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore maiores iusto nihil doloremque autem quia dicta
      velit eius, asperiores facere iste minus cumque tenetur quo suscipit ex, eos similique modi.</p>
  </div>
</div>
<?php require_once('inc/templates/footer.php') ?>