<?php
$title = '(External)';

require_once('inc/templates/header.php')
?>

<div class="container py-5">
  <div class="py-5">
    <h1>External Website</h1>
    <p class="text-info">The link you have just clicked will open a external website on the live website!</p>
  </div>
</div>
<?php require_once('inc/templates/footer.php') ?>